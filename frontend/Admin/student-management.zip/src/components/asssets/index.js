import logo from './logo.png';
const image = {
  logo,
};

export default image;
