// export async function addZone(payload) {
//     let res = await fetch(`${API_URL}/zone/add`, {
//       method: "POST",
//       headers: headersJsonToken(),
//       body: JSON.stringify(payload),
//     })
//       .then((res) => res.json())
//       .then((data) => {
//         return data;
//       });
//     return res;
//   }