// import { useMutation } from "react-query"

// export const useAddTeacher = (options) => {
//     return useMutation((payload) => AddTeacher(payload), options)
// }