import { useEffect } from 'react';
import axios from "axios";
import React, { useState } from 'react';

const data = []
export default function List() {
    const day = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Semedi']
    const time = ['7h00-7h55', '8h00-8h55', '9h10-10h05','10h10-11h05','13h00-13h55','14h00-14h55','15h10-16h05','16h10-17h05']
    const time2 = ['7:00','9:00','11:00','13:00','15:00','17:00']
    let room = []
    let rows = []
    const [rooms, setRooms] = useState([])
    const [row,setRow] = useState([])
    const [test,setTest] = useState([])
    
    useEffect( () => {
        axios.get("http://localhost:3000/admin/get/room", { withCredentials: true })
        .then((result)=>{
            room.push('Horairres')
            room.push('Moment')
            for (var i=0 ; i<result.data.results.length; i++){
                room.push(result.data.results[i].room)
                rows.push(result.data.results[i].room)
            }
            setRooms(room)
            setRow(rows)
        })
        handleData()
        console.log(test)
      }, [])

      async function handleData () {
        console.log('sss')
        // axios.post("http://localhost:3000/admin/get/roomTable",{room: row[0],startTime: '9:00', date: day[4]}, { withCredentials: true })
            for (let i=0 ; i<row.length ; i++){
                for( let j=0 ; j<day.length ; j++){
                    for (let k=0 ; k<time2.length ;k++){
                        const response = await axios.post("http://localhost:3000/admin/get/roomTable",{room: row[i],startTime: time2[k], date: day[j]}, { withCredentials: true })
                            if(response.data.results.length==1){
                                data.push(i+'-'+j+'-'+k)
                                setTest(data)
                            }
                        }
                    }
            }
      }
    

    return(
        <div> 
            <tbody style={{textAlign:'center'}}>
                <tr>
                    {(
                        rooms.map((data) => 
                            <td style={{border:'1px solid black', margin: 'auto', padding:'auto'}}>{data}</td>
                        )
                    )}
                </tr>
                {(
                    day.map((data) => 
                        <tr style={{border:'1px solid black', margin: 'auto', padding:'auto'}}>
                            <td style={{ backgroundColor: 'gray',border:'1px solid black', margin: 'auto', padding:'auto'}}>{data}</td>
                            <td style={{backgroundColor:"orange"}}>
                                    {(
                                        time.map((time) => 
                                        <tr style={{border:'1px solid black', margin: 'auto', padding:'auto'}}>
                                            <td style={{border:'1px solid black', margin: 'auto', padding:'auto'}}>{time}</td>
                                        </tr>
                                        )
                                    )}
                            </td>
                            {(
                                row.map((data1) => 
                                <td>
                                    {(
                                        time.map((test) => 
                                        <tr style={{border:'1px solid black', margin: 'auto', padding:'auto'}}>
                                            <td style={{border:'1px solid black', margin: 'auto', padding:'auto'}}>{test}</td>
                                        </tr>
                                        )
                                    )}
                                </td>
                                )
                            )}
                        </tr>
                    )
                )}
            </tbody>
        </div>
    )
}